(function($) {
 $.widget('ui.captionator', {

 });
})(jQuery);