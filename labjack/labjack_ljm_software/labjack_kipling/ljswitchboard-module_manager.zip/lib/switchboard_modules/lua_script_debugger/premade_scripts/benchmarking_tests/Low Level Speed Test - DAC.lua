print("Benchmarking Test: Low-Level DAC voltage output test.  ..unimplemented")
--If you need this benchmarking test, let us know.  support@labjack.com
--Test is not yet implemented.  Currently the fastest way to update a DAC is to use
--MB.W(1000, 3, 2.5)    --write 2.5V to DAC0. Address is 1000, type is 3