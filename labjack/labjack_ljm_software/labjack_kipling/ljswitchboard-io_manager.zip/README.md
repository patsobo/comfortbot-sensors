ljswitchboard-io_manager
==========

A promise based &amp; multi-process based wrapper for the labjack-nodejs library that also includes logging and other features.  Primarily to be used in the ljswitchboard project.
